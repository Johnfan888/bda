# -*- coding: utf-8 -*-
"""
Created on Mon Mar  5 15:25:39 2018
@author: dell-1
了解数据，初步认识数据
主要功能：绘制图，查看各个特征和血糖之间的关系
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

import seaborn as sns

from scipy import stats
from scipy.stats import norm, skew
import matplotlib

matplotlib.rcParams['font.sans-serif'] = ['Microsoft YaHei'] #指定默认字体  
matplotlib.rcParams['axes.unicode_minus'] = False # 解决保存图像是负号'-'显示为方块的问题

data_path = 'E:\\糖尿病\\data\\'

train = pd.read_csv(data_path+'d_train.csv',encoding='gb18030')
train = train.fillna(train.mean())
#train['log_age']= np.log(train['age'])

#查看血糖的分析
var = 'xhb'
sns.distplot(train[var],fit=norm)
(mu,sigma) = norm.fit(train[var])
print( '\n mu = {:.2f} and sigma = {:.2f}\n'.format(mu, sigma))
#Now plot the distribution
plt.legend(['Normal dist. ($\mu=$ {:.2f} and $\sigma=$ {:.2f} )'.format(mu, sigma)],
            loc='best')
plt.ylabel('Frequency')
plt.title('血糖分布')

fig = plt.figure()
res = stats.probplot(train[var], plot=plt)
plt.show()


'''
#查看类别型对血糖的影响
var = '性别'
data = pd.concat([train['血糖'], train[var]], axis=1)
f, ax = plt.subplots(figsize=(8, 6))
fig = sns.boxplot(x=var, y="血糖", data=data)
fig.axis(ymin=0, ymax=45);


#查看数值型对血糖的影响
var = '中性粒细胞%'
data = pd.concat([train['血糖'], train[var]], axis=1)
data.plot.scatter(x=var, y='血糖', ylim=(0,50));


#查看相关系数矩阵
corrmat = train.corr()
f, ax = plt.subplots(figsize=(12, 9))
sns.heatmap(corrmat, vmax=.8, square=True)


k = 20 #number ofvariables for heatmap
cols = corrmat.nlargest(k, 'xtang')['xtang'].index
cm = np.corrcoef(train[cols].values.T)
sns.set(font_scale=1.25)
hm = sns.heatmap(cm, cbar=True, annot=True, square=True, fmt='.2f', annot_kws={'size': 10}, 
yticklabels=cols.values, xticklabels=cols.values,)
plt.show()
'''