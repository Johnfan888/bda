# -*- coding: utf-8 -*-
"""
Created on Sun Mar  4 17:26:15 2018
@author: dell-1

lgb的参数
"""


import multiprocessing
# ================= LightGBM parameters ====================
lgb_params = {
    'objective': 'regression',
    'boosting': 'gbdt',
    'learning_rate': 0.01,
    'num_leaves': 63,
    # 'max_depth': 5,
    'num_threads': multiprocessing.cpu_count() // 2,
    'lambda_l1': 0.01,
    'lambda_l2': 0.01,
    'metric': 'mse',
    'verbose': 1,
    'feature_fraction': .7,
    'feature_fraction_seed': 2,
    'bagging_fraction': 0.7,
    'bagging_freq': 5,
    'bagging_seed': 3,
    'min_data_in_leaf': 100,
    'min_sum_hessian_in_leaf': 11,
    'max_bin': 800,
}

num_boost_round = 3000
early_stopping_rounds = 100

