# -*- coding: utf-8 -*-
"""
Created on Sun Mar  4 17:25:31 2018
@author: dell-1
目标函数
"""

import numpy as np


def mse(preds, train_data):
    labels = train_data.get_label().squeeze()
    return 'mse', np.mean((preds.round(2) - labels)**2)/2, False
